# 1-3 行列式计算.py

'''
获取输入的字符串，用split方法变成列表，用map函数将列表每一个元素化成整型
当然，可以使用a,b,c=[int(element) for element in input().split()]得到同样的效果
下面这样写的代码是最麻烦的
a11,a12,a13 = input().split()
a21,a22,a23 = input().split()
a31,a32,a33 = input().split()
a11 = int(a11)
a12 = int(a12)
a13 = int(a13)
a21 = int(a21)
a22 = int(a22)
a23 = int(a23)
a31 = int(a31)
a32 = int(a32)
a33 = int(a33)
'''

a11,a12,a13=map(int,input().split())
a21,a22,a23=map(int,input().split())
a31,a32,a33=map(int,input().split())

#利用题干给出的行列式计算公式算出结果并输出
ans = a11*a22*a33+a12*a23*a31+a13*a21*a32-a13*a22*a31-a12*a21*a33-a11*a23*a32

print("%.2f" % ans)

'''
输入样例1：
11 12 13
21 22 23
31 32 33
输出样例1：
0.00

输入样例1：
1 1 4
5 1 4
19 19 801
输出样例2：
-2900.00
'''
