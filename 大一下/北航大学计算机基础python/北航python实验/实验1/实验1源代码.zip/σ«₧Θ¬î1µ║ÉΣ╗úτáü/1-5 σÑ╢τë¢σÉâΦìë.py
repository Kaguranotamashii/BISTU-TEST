#1-5 奶牛吃草

#输入道路的名字 两侧长草情况
name = input()
a,b=map(int,input().split()) 


#按位与运算得出适合就餐的场地的十进制数
suit = a&b
#按位或运算得出可以就餐的场地的十进制数
can = a|b

#输出道路的名字、两个十进制数
print(name)
print(suit)
print(can)

'''
输入样例1：
Lane
3 5
输出样例1：
1
7

输入样例2：
Fim
6522 18566

输出样例2：
Fim
2050
23038


'''


