# 1-1 海伦公式

import math

#读入三个浮点数
a=float(input())
b=float(input())
c=float(input())

#计算p
p=(a+b+c)/2
#利用公式计算面积
s=math.sqrt(p*(p-a)*(p-b)*(p-c))

#格式化输出保留1位小数
print("%.1f" %s)


'''
输入样例1：
3
4
5
输出样例1：
6.0

输入样例2：
3.3
4.4
5.5
输出样例2：
7.3

'''


